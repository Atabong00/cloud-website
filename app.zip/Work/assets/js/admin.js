// Check Auth
const params = new URLSearchParams(window.location.search);
const currentUser = AuthService.checkAuth('admin');
document.getElementById('admin-name-display').textContent = currentUser.name;

// Navigation Logic
function showSection(id) {
    document.querySelectorAll('.content-section').forEach(el => el.style.display = 'none');
    document.getElementById(id).style.display = 'block';
    document.querySelectorAll('.nav-link').forEach(el => el.classList.remove('active'));
    document.querySelector(`a[href="#${id}"]`).classList.add('active');
    renderSection(id);
}

async function renderSection(id) {
    if (id === 'dashboard') await renderDashboard();
    if (id === 'students') await renderUsers('student');
    if (id === 'masters') await renderUsers('master');
    if (id === 'courses') await renderCourses();
    if (id === 'certificates') await renderCertificates();
    if (id === 'feedbacks') await renderFeedback();
    if (id === 'results') await renderResults();
    if (id === 'scanner-section') { /* Scanner UI handled by buttons */ }

    // Stop scanner if leaving section
    if (id !== 'scanner-section' && (typeof adminScanner !== 'undefined' && adminScanner)) {
        stopAdminScanner();
    }
}

async function renderDashboard() {
    const users = await DataService.getUsers();
    const students = users.filter(u => u.role === 'student').length;
    const courses = await DataService.getCourses();
    const certs = await DataService.getCertificates();

    document.getElementById('stat-students').innerText = students;
    document.getElementById('stat-courses').innerText = courses.length;
    document.getElementById('stat-certs').innerText = certs.length;
}

async function renderUsers(role) {
    const allUsers = await DataService.getUsers();
    const list = allUsers.filter(u => u.role === role);
    const tbody = document.getElementById(role === 'student' ? 'table-students' : 'table-masters');
    tbody.innerHTML = ''; // Clear

    const enrollments = await DataService.getEnrollments();
    const courses = await DataService.getCourses();

    list.forEach(u => {
        const uEnrollments = role === 'student' ? enrollments.filter(e => e.studentId === u.id).length : '-';
        const coursesTaught = role === 'master' ? courses.filter(c => c.masterId === u.id).length : '-';

        const row = `
            <tr>
                <td>${u.name}</td>
                <td>${u.email}</td>
                <td>${role === 'student' ? (u.regNo || 'N/A') : (u.title || 'Instructor')}</td>
                <td>${role === 'student' ? uEnrollments : coursesTaught}</td>
                <td>
                    <button class="btn btn-sm btn-danger" onclick="deleteUser('${u.id}', '${role}')">Delete</button>
                </td>
            </tr>
        `;
        tbody.innerHTML += row;
    });
}

async function renderCourses() {
    const courses = await DataService.getCourses();
    const users = await DataService.getUsers();
    const allEnrollments = await DataService.getEnrollments();
    const tbody = document.getElementById('table-courses');
    tbody.innerHTML = '';

    courses.forEach(c => {
        const master = users.find(u => u.id === c.masterId)?.name || 'Unassigned';
        const count = allEnrollments.filter(e => e.courseId === c.id).length;
        const row = `
            <tr>
                <td>${c.code}</td>
                <td>${c.name}</td>
                <td>${c.credits}</td>
                <td>${master}</td>
                <td>${count}</td>
                <td><button class="btn btn-sm btn-danger" onclick="deleteCourse('${c.id}')">Delete</button></td>
            </tr>
        `;
        tbody.innerHTML += row;
    });
}

async function renderCertificates() {
    // Populate Selects
    const allUsers = await DataService.getUsers();
    const students = allUsers.filter(u => u.role === 'student');
    const courses = await DataService.getCourses();

    const selStudent = document.getElementById('cert-student');

    // Refresh options if empty or just placeholder
    if (selStudent.options.length <= 1) {
        // preserve current selection? Hard to do with async refresh, simplify resets.
        selStudent.innerHTML = '<option selected>Select Student...</option>';
        students.forEach(u => {
            selStudent.innerHTML += `<option value="${u.id}">${u.name} (${u.regNo})</option>`;
        });
    }

    // Render Table
    const certs = await DataService.getCertificates();
    const tbody = document.getElementById('table-certs');
    tbody.innerHTML = '';

    // Sort Newest first
    [...certs].reverse().forEach(crt => {
        const sName = students.find(s => s.id === crt.studentId)?.name || 'Unknown';

        let cNames = 'Unknown';
        if (Array.isArray(crt.courseIds)) {
            // Multi course
            cNames = crt.courseIds.map(cid => {
                const c = courses.find(co => co.id === cid);
                return c ? c.code : '?';
            }).join(', ');
        } else {
            // Legacy single course
            const c = courses.find(co => co.id === crt.courseId);
            cNames = c ? c.code : 'Unknown';
        }

        tbody.innerHTML += `<tr><td>${crt.id}</td><td>${sName}</td><td>${cNames}</td><td>${new Date(crt.issueDate).toLocaleDateString()}</td><td>${crt.expiryDate || '-'}</td></tr>`;
    });
}

async function renderFeedback() {
    const list = await DataService.getFeedback();
    const tbody = document.getElementById('table-feedback');
    tbody.innerHTML = '';

    // Newest first
    [...list].reverse().forEach(f => {
        tbody.innerHTML += `
            <tr>
                <td>${new Date(f.date).toLocaleString()}</td>
                <td>${f.userName}</td>
                <td><span class="badge badge-warning">${f.userRole}</span></td>
                <td>${f.message}</td>
            </tr>
        `;
    });
}

async function renderResults() {
    const allEnrollments = await DataService.getEnrollments();
    const enrollments = allEnrollments.filter(e => e.marks !== null || e.grade !== null); // Only show graded ones
    const users = await DataService.getUsers();
    const courses = await DataService.getCourses();
    const tbody = document.getElementById('table-results');
    tbody.innerHTML = '';

    if (enrollments.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center">No grades submitted yet.</td></tr>';
        return;
    }

    enrollments.forEach(e => {
        const student = users.find(u => u.id === e.studentId);
        const course = courses.find(c => c.id === e.courseId);
        const statusBadge = e.published
            ? '<span class="badge badge-success">Published</span>'
            : '<span class="badge badge-warning">Pending</span>';

        // Check types strictly. Published maps to 1 in DB sometimes sent as string.
        const isPub = (e.published == 1 || e.published === '1' || e.published === true);

        const actionBtn = isPub
            ? '<button class="btn btn-sm btn-secondary" disabled>Published</button>'
            : `<button class="btn btn-sm btn-primary" onclick="publishResult('${e.id}')">Publish</button>`;

        tbody.innerHTML += `
            <tr>
                <td>${student ? student.name : 'Unknown'}</td>
                <td>${course ? course.code : 'Unknown'}</td>
                <td>${e.marks || '-'}</td>
                <td>${e.grade || '-'}</td>
                <td>${statusBadge}</td>
                <td>${actionBtn}</td>
            </tr>
        `;
    });
}

// --- Action Functions ---

async function openModal(id) {
    document.getElementById(id).style.display = 'flex';
    if (id === 'modal-course') {
        // Pop Master Select
        const allUsers = await DataService.getUsers();
        const masters = allUsers.filter(u => u.role === 'master');
        const sel = document.getElementById('course-master');
        sel.innerHTML = '';
        masters.forEach(m => sel.innerHTML += `<option value="${m.id}">${m.name}</option>`);
    }
}
function closeModal() { document.querySelectorAll('.modal').forEach(m => m.style.display = 'none'); }

async function addUser() {
    const name = document.getElementById('add-name').value;
    const email = document.getElementById('add-email').value;
    const dob = document.getElementById('add-dob').value;
    const role = document.getElementById('add-role').value;

    if (!name || !email) return alert('Fill all fields');

    const newUser = {
        id: 'u' + Date.now(),
        name, email, dob,
        password: '123',
        role,
        regNo: role === 'student' ? 'REG' + Date.now() : undefined
    };

    // Using generic Add which calls API 'addUser'
    const result = await DataService.add('vg_users', newUser);

    if (result && result.success) {
        closeModal();
        await renderUsers(role); // Refresh
        await renderDashboard();
    } else {
        alert('Failed to add user: ' + (result?.message || 'Error'));
    }
}

async function deleteUser(id, role) {
    if (confirm('Are you sure?')) {
        await DataService.remove('vg_users', id);
        await renderUsers(role);
        await renderDashboard();
    }
}

async function addCourse() {
    const name = document.getElementById('course-name').value;
    const code = document.getElementById('course-code').value;
    const credits = document.getElementById('course-credits').value;
    const masterId = document.getElementById('course-master').value;

    if (!name || !code) return alert('Fill all fields');

    const result = await DataService.add('vg_courses', {
        id: 'c' + Date.now(),
        name, code, credits, masterId
    });

    if (result && result.success) {
        closeModal();
        await renderCourses();
        await renderDashboard(); // Update counts
    } else {
        alert('Failed to add course');
    }
}

async function deleteCourse(id) {
    if (confirm('Delete this course?')) {
        await DataService.remove('vg_courses', id);
        await renderCourses();
        await renderDashboard();
    }
}

async function publishResult(id) {
    if (confirm('Publish this result to the student?')) {
        await DataService.updateEnrollment(id, { published: true });
        await renderResults();
    }
}

async function loadStudentCoursesForCert() {
    const studentId = document.getElementById('cert-student').value;
    const container = document.getElementById('cert-courses-checkboxes');
    container.innerHTML = '';

    if (studentId === 'Select Student...') {
        container.innerHTML = '<p class="text-muted" style="font-size:0.9rem">Select a student first.</p>';
        return;
    }

    const allEnrollments = await DataService.getEnrollments();
    const enrollments = allEnrollments.filter(e => e.studentId === studentId);
    const courses = await DataService.getCourses();

    if (enrollments.length === 0) {
        container.innerHTML = '<p class="text-muted" style="font-size:0.9rem">No courses found for this student.</p>';
        return;
    }

    enrollments.forEach(e => {
        const c = courses.find(co => co.id === e.courseId);
        if (c) {
            container.innerHTML += `
                <div style="margin-bottom:5px;">
                    <input type="checkbox" name="cert-course-select" value="${c.id}" id="chk-${c.id}">
                    <label for="chk-${c.id}">${c.code} - ${c.name}</label>
                </div>
             `;
        }
    });
}

async function generateCertificate() {
    const studentId = document.getElementById('cert-student').value;
    const expiryDate = document.getElementById('cert-expiry').value;

    if (!studentId || studentId === 'Select Student...') return alert('Please select a valid student');

    // Get selected courses
    const checkboxes = document.querySelectorAll('input[name="cert-course-select"]:checked');
    if (checkboxes.length === 0) return alert('Select at least one course.');

    const courseIds = Array.from(checkboxes).map(cb => cb.value);

    // Get Student
    const users = await DataService.getUsers();
    const student = users.find(u => u.id === studentId);

    // Generate ID
    const certId = 'CERT-' + Math.random().toString(36).substr(2, 6).toUpperCase();
    const issueDate = new Date().toISOString().split('T')[0]; // Format for Date Input interaction if needed, or ISO

    const newCert = {
        id: certId,
        studentId,
        courseIds,
        candidateName: student.name,
        dob: student.dob || 'N/A',
        issueDate: issueDate,
        expiryDate: expiryDate || 'N/A'
    };

    const result = await DataService.issueCertificate(newCert);

    if (result && result.success) {
        // Show Preview
        document.getElementById('cert-preview').style.display = 'block';

        // Create Verification URL
        const verifyPath = window.location.pathname.replace('admin.html', 'verify.html');
        const verifyUrl = `${window.location.origin}${verifyPath}?id=${certId}`;

        document.getElementById('cert-id-display').innerHTML = `
            ${certId}<br>
            <span style="font-size:0.8rem; font-weight:normal">Issued to: ${newCert.candidateName}</span><br>
            <span style="font-size:0.8rem; font-weight:normal">Courses: ${courseIds.length} included</span>
        `;

        const qrContainer = document.getElementById('qr-container');
        qrContainer.innerHTML = '';
        new QRCode(qrContainer, {
            text: verifyUrl,
            width: 128,
            height: 128
        });

        await renderCertificates();
        await renderDashboard();
    } else {
        alert('Failed to generate certificate');
    }
}

async function postAnnouncement() {
    const title = document.getElementById('announce-title').value;
    const content = document.getElementById('announce-content').value;
    const type = document.getElementById('announce-type').value;

    if (!title || !content) return;

    const result = await DataService.addPost({
        title, content, type,
        authorId: currentUser.id,
        authorRole: 'admin',
        courseId: 'GLOBAL',
        date: new Date().toISOString()
    });

    if (result && result.success) {
        alert('Announcement Posted System-Wide');
        document.getElementById('announce-title').value = '';
        document.getElementById('announce-content').value = '';
    }
}

// Initial Render
showSection('dashboard');
