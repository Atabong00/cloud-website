// Auth
const currentUser = AuthService.checkAuth('student');
document.getElementById('student-name').innerText = currentUser.name;

// --- Navigation ---
function showSection(id) {
    document.querySelectorAll('.content-section').forEach(el => el.style.display = 'none');
    document.getElementById(id).style.display = 'block';

    document.querySelectorAll('.sidebar a').forEach(a => a.classList.remove('active'));
    // approximate active link check
    renderSection(id);
}

showSection('dashboard');

async function renderSection(id) {
    if (id === 'dashboard') await loadDashboard();
    if (id === 'registration') await loadAvailableCourses();
    if (id === 'my-courses') await loadMyCourses();
    if (id === 'certificates') await loadCertificates();
}

// --- Logic ---

async function loadDashboard() {
    const allEnrollments = await DataService.getEnrollments();
    const enrollments = allEnrollments.filter(e => e.studentId === currentUser.id);

    const allCerts = await DataService.getCertificates();
    const certs = allCerts.filter(c => c.studentId === currentUser.id);

    document.getElementById('stat-enrolled').innerText = enrollments.length;
    document.getElementById('stat-certs').innerText = certs.length;
    // Mock GPA
    document.getElementById('stat-gpa').innerText = '3.8';

    // Recent Feed (System wide or my courses)
    const myCourseIds = enrollments.map(e => e.courseId);

    const allPosts = await DataService.getPosts();
    const posts = allPosts.filter(p => myCourseIds.includes(p.courseId) || p.courseId === 'GLOBAL');

    const feed = document.getElementById('feed-recent');
    feed.innerHTML = '';

    posts.slice(0, 3).forEach(p => {
        feed.innerHTML += `
            <div class="card mb-1" style="padding:1rem;">
                <h4>${p.title} <span class="badge badge-warning" style="font-size:0.6rem">${p.type}</span></h4>
                <p>${p.content}</p>
                <small class="text-muted">${new Date(p.date).toLocaleString()}</small>
            </div>
        `;
    });
}

async function loadAvailableCourses() {
    const courses = await DataService.getCourses();
    const allEnrollments = await DataService.getEnrollments();
    const myEnrollments = allEnrollments.filter(e => e.studentId === currentUser.id);
    const myCourseIds = myEnrollments.map(e => e.courseId);

    const container = document.getElementById('available-courses-list');
    container.innerHTML = '';

    courses.forEach(c => {
        const isEnrolled = myCourseIds.includes(c.id);
        const btn = isEnrolled
            ? `<button class="btn btn-secondary btn-sm" disabled>Enrolled</button>`
            : `<button class="btn btn-primary btn-sm" onclick="enroll('${c.id}')">Enroll</button>`;

        container.innerHTML += `
            <div class="course-card mb-1">
                <div>
                    <h3>${c.code}</h3>
                    <p>${c.name} (${c.credits} Credits)</p>
                </div>
                ${btn}
            </div>
        `;
    });
}

async function enroll(courseId) {
    const result = await DataService.enrollStudent(currentUser.id, courseId);
    if (result && result.success) {
        alert('Enrolled Successfully!');
        loadAvailableCourses();
    } else {
        alert('Enrollment Failed: ' + (result?.message || 'Unknown Error'));
    }
}

async function loadMyCourses() {
    const allEnrollments = await DataService.getEnrollments();
    const enrollments = allEnrollments.filter(e => e.studentId === currentUser.id);

    const courses = await DataService.getCourses();
    const list = document.getElementById('active-courses-list');
    list.innerHTML = '';

    enrollments.forEach(e => {
        const c = courses.find(co => co.id === e.courseId);
        if (c) {
            list.innerHTML += `
                <div class="course-card mb-1">
                    <div>
                        <h3>${c.code}: ${c.name}</h3>
                        <span class="badge badge-success">Active</span>
                        ${e.published && e.grade ? `<span class="badge badge-warning" style="margin-left:5px;">Grade: ${e.grade} (${e.marks}%)</span>` : ''}
                    </div>
                    <button class="btn btn-secondary btn-sm" onclick="viewBoard('${c.id}')">View Board / Notices</button>
                </div>
            `;
        }
    });
}

async function viewBoard(courseId) {
    const allPosts = await DataService.getPosts();
    const posts = allPosts.filter(p => p.courseId === courseId);
    document.getElementById('course-board-view').style.display = 'block';
    const container = document.getElementById('board-posts');
    container.innerHTML = '';

    if (posts.length === 0) container.innerHTML = '<p>No notices.</p>';
    posts.forEach(p => {
        container.innerHTML += `<div style="border-bottom:1px solid #eee; padding:10px 0;"><strong>${p.title}</strong><br>${p.content}</div>`;
    });
}
function closeBoard() { document.getElementById('course-board-view').style.display = 'none'; }

async function printRegistration() {
    // Populate Print Area
    const allEnrollments = await DataService.getEnrollments();
    const enrollments = allEnrollments.filter(e => e.studentId === currentUser.id);
    const courses = await DataService.getCourses();

    document.getElementById('print-name').innerText = currentUser.name;
    document.getElementById('print-reg').innerText = currentUser.regNo || 'N/A';
    document.getElementById('print-date').innerText = new Date().toLocaleDateString();

    const tbody = document.getElementById('print-courses-body');
    tbody.innerHTML = '';

    enrollments.forEach(e => {
        const c = courses.find(co => co.id === e.courseId);
        if (c) {
            tbody.innerHTML += `<tr><td>${c.code}</td><td>${c.name}</td><td>${c.credits}</td></tr>`;
        }
    });

    window.print();
}

function simulatePayment() {
    const amount = document.getElementById('pay-amount').value;
    if (!amount) return;
    alert(`Payment of $${amount} Successful!`);
    document.getElementById('wallet-balance').innerText = '$' + (500 - parseFloat(amount)).toFixed(2);
    document.getElementById('pay-amount').value = '';
}

async function loadCertificates() {
    const allCerts = await DataService.getCertificates();
    const certs = allCerts.filter(c => c.studentId === currentUser.id);
    const courses = await DataService.getCourses();

    const container = document.getElementById('certs-list');
    container.innerHTML = '';

    certs.forEach(cert => {
        let certCourseIds = cert.courseIds;
        let courseName = 'Certificate';
        if (Array.isArray(certCourseIds) && certCourseIds.length > 0) {
            const c = courses.find(co => co.id === certCourseIds[0]);
            if (c) courseName = c.name;
            if (certCourseIds.length > 1) courseName += ` + ${certCourseIds.length - 1} more`;
        }

        const divId = `qr-${cert.id}`;

        // Create Verification URL
        const verifyPath = window.location.pathname.replace('student.html', 'verify.html');
        const verifyUrl = `${window.location.origin}${verifyPath}?id=${cert.id}`;

        container.innerHTML += `
            <div class="card text-center">
                <h3>${courseName}</h3>
                <p class="text-muted">Issued: ${new Date(cert.issueDate).toLocaleDateString()}</p>
                <p class="text-muted" style="font-size:0.9rem">Expires: ${cert.expiryDate || 'Never'}</p>
                <div id="${divId}" style="margin:1rem auto; display:inline-block;"></div>
                <p style="font-weight:bold; font-family:monospace;">${cert.id}</p>
            </div>
        `;

        // Wait for DOM
        setTimeout(() => {
            new QRCode(document.getElementById(divId), {
                text: verifyUrl,
                width: 100, height: 100
            });
        }, 100);
    });
}

async function submitFeedback() {
    const msg = document.getElementById('feedback-msg').value;
    if (!msg) return alert('Please enter a message');

    const result = await DataService.addFeedback({
        userId: currentUser.id,
        userRole: 'student',
        userName: currentUser.name,
        message: msg
    });

    if (result && result.success) {
        alert('Feedback Sent!');
        document.getElementById('feedback-msg').value = '';
    } else {
        alert('Failed to send feedback');
    }
}
