/**
 * DataService - Manages all Database operations via API
 */

const API_URL = 'api/api.php';

const DataService = {
    // Generic Fetcher
    async fetch(action, params = {}, method = 'GET') {
        let url = `${API_URL}?action=${action}`;
        let options = { method };

        if (method === 'POST') {
            options.headers = { 'Content-Type': 'application/json' };
            options.body = JSON.stringify({ action, ...params });
        }

        try {
            const res = await fetch(url, options);
            const text = await res.text();
            try {
                return JSON.parse(text);
            } catch (e) {
                console.error("JSON Parse Error:", text);
                return [];
            }
        } catch (err) {
            console.error('API Error:', err);
            return [];
        }
    },

    // Users
    async getUsers() { return await this.fetch('getUsers'); },
    async getUserByEmail(email) {
        const users = await this.getUsers();
        return users.find(u => u.email === email);
    },

    // Courses
    async getCourses() { return await this.fetch('getCourses'); },

    async addCourse(course) {
        // We need a specific endpoint or generic add. 
        // Currently API supports: enrollStudent, addPost, addFeedback, issueCertificate
        // We probably need addCourse to be added to API.
        // For now, assuming "addCourse" generic or specific.
        // Let's use generic "add" if possible or add standard POST.
        // Wait, I implemented: enrollStudent, addPost, addFeedback, issueCertificate, updateEnrollment
        // I MISSED: addCourse, addUser, remove...
        // I will need to update api/api.php to support these or handle it.
        // Let's assume I will update api.php to support 'addCourse' and 'addUser'.
        return await this.fetch('addCourse', course, 'POST');
    },

    // Enrollments
    async getEnrollments() { return await this.fetch('getEnrollments'); },
    async enrollStudent(studentId, courseId) {
        return await this.fetch('enrollStudent', { studentId, courseId }, 'POST');
    },
    async updateEnrollment(id, updates) {
        return await this.fetch('updateEnrollment', { id, ...updates }, 'POST');
    },

    // Certificates
    async getCertificates() { return await this.fetch('getCertificates'); },
    async issueCertificate(certData) {
        return await this.fetch('issueCertificate', certData, 'POST');
    },

    // Posts (Notices)
    async getPosts() { return await this.fetch('getPosts'); },
    async addPost(post) { return await this.fetch('addPost', post, 'POST'); },

    // Feedback
    async getFeedback() { return await this.fetch('getFeedback'); },
    async addFeedback(fb) { return await this.fetch('addFeedback', fb, 'POST'); },

    // Generic Add/Remove Wrappers (Backward compatibility or future proofing)
    // NOTE: These were sync in original. Now Async.
    async add(type, item) {
        switch (type) {
            case 'vg_users': return await this.fetch('addUser', item, 'POST'); // Needs implementation in API
            case 'vg_courses': return await this.fetch('addCourse', item, 'POST'); // Needs implementation in API
            // ...
        }
    },

    async remove(type, id) {
        // Needs generic remove endpoint
        return await this.fetch('deleteItem', { type, id }, 'POST');
    },

    // Helpers
    generateId(prefix) { return prefix + Math.random().toString(36).substr(2, 9).toUpperCase(); }
};

// Simple Auth Helper
const AuthService = {
    async login(email, password) {
        try {
            const res = await fetch('api/login.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });
            const data = await res.json();

            if (data.success) {
                sessionStorage.setItem('vg_session', JSON.stringify(data.user));
                return data.user;
            }
            return null;
        } catch (e) {
            console.error(e);
            return null;
        }
    },
    logout() {
        sessionStorage.removeItem('vg_session');
        window.location.href = 'index.html';
    },
    getCurrentUser() {
        return JSON.parse(sessionStorage.getItem('vg_session'));
    },
    checkAuth(role) {
        const user = this.getCurrentUser();
        if (!user) {
            window.location.href = 'index.html';
            return;
        }
        if (role && user.role !== role && user.role !== 'admin') {
            if (role === 'master' && user.role !== 'master') window.location.href = 'index.html';
            if (role === 'student' && user.role !== 'student') window.location.href = 'index.html';
        }
        return user;
    }
};
