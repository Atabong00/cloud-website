<?php
require_once 'db.php';

try {
    $sql = file_get_contents('../database.sql');

    // Split SQL into individual queries because PDO might not like multiple at once depending on config
    // or just use exec if it supports it.
    // The safest is to use the pdo connection from db.php which connects to the DB name.
    // BUT database.sql contains "CREATE DATABASE" and "USE".
    // If db.php connects to 'verify_grade_db' which doesn't exist yet, it will fail.

    // let's override the connection to connect to just localhost first
    $host = 'localhost';
    $user = 'root';
    $pass = '';
    $pdo_root = new PDO("mysql:host=$host", $user, $pass);
    $pdo_root->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Execute the SQL
    $pdo_root->exec($sql);

    echo "Database setup completed successfully.";
} catch (PDOException $e) {
    die("DB Setup Failed: " . $e->getMessage());
}
?>