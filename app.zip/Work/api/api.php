<?php
require_once 'db.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

// For POST requests, we might receive JSON
$input = json_decode(file_get_contents('php://input'), true);

if ($method === 'GET') {
    switch ($action) {
        case 'getUsers':
            $stmt = $pdo->query("SELECT * FROM users");
            echo json_encode($stmt->fetchAll());
            break;

        case 'getCourses':
            $stmt = $pdo->query("SELECT * FROM courses");
            echo json_encode($stmt->fetchAll());
            break;

        case 'getEnrollments':
            $stmt = $pdo->query("SELECT * FROM enrollments");
            echo json_encode($stmt->fetchAll());
            break;

        case 'getCertificates':
            // we need to parse courseIds as it is stored as JSON string in DB, 
            // but fetchAll returns it as string. JS side JSON.parse handles it? 
            // In DB seed: '["c1"]'. JS expects array. 
            // We can decode here or let JS handle it. JS JSON.parse on a JSON string is fine.
            $stmt = $pdo->query("SELECT * FROM certificates");
            $certs = $stmt->fetchAll();
            foreach ($certs as &$cert) {
                $cert['courseIds'] = json_decode($cert['courseIds']);
            }
            echo json_encode($certs);
            break;

        case 'getPosts':
            $stmt = $pdo->query("SELECT * FROM posts ORDER BY date DESC");
            echo json_encode($stmt->fetchAll());
            break;

        case 'getFeedback':
            $stmt = $pdo->query("SELECT * FROM feedback ORDER BY date DESC");
            echo json_encode($stmt->fetchAll());
            break;

        default:
            echo json_encode(['error' => 'Invalid action']);
            break;
    }
} elseif ($method === 'POST') {
    // If action is in query string or body. Let's check query string first.
    if (!$action && isset($input['action']))
        $action = $input['action'];

    switch ($action) {
        case 'enrollStudent':
            $id = $input['id'] ?? uniqid('e');
            $studentId = $input['studentId'];
            $courseId = $input['courseId'];
            $date = date('Y-m-d H:i:s');

            // Check existence
            $check = $pdo->prepare("SELECT id FROM enrollments WHERE studentId=? AND courseId=?");
            $check->execute([$studentId, $courseId]);
            if ($check->fetch()) {
                echo json_encode(['success' => false, 'message' => 'Already enrolled']);
                exit;
            }

            $stmt = $pdo->prepare("INSERT INTO enrollments (id, studentId, courseId, date) VALUES (?, ?, ?, ?)");
            if ($stmt->execute([$id, $studentId, $courseId, $date])) {
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false, 'error' => $stmt->errorInfo()]);
            }
            break;

        case 'addPost':
            $id = $input['id'] ?? uniqid('p');
            $title = $input['title'];
            $content = $input['content'];
            $type = $input['type'] ?? 'notice';
            $authorId = $input['authorId']; // ensure these are passed
            $role = $input['authorRole'] ?? 'admin';
            $courseId = $input['courseId'] ?? 'GLOBAL';
            $date = date('Y-m-d H:i:s');

            $stmt = $pdo->prepare("INSERT INTO posts (id, title, content, type, authorId, authorRole, courseId, date) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            if ($stmt->execute([$id, $title, $content, $type, $authorId, $role, $courseId, $date])) {
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false, 'error' => $stmt->errorInfo()]);
            }
            break;

        case 'addFeedback':
            $userName = $input['userName'];
            $userRole = $input['userRole'];
            $message = $input['message'];
            $date = date('Y-m-d H:i:s');

            $stmt = $pdo->prepare("INSERT INTO feedback (userName, userRole, message, date) VALUES (?, ?, ?, ?)");
            if ($stmt->execute([$userName, $userRole, $message, $date])) {
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false]);
            }
            break;

        case 'issueCertificate':
            $id = $input['id'];
            $studentId = $input['studentId'];
            $candidateName = $input['candidateName'];
            $courseIds = json_encode($input['courseIds']);
            $issueDate = $input['issueDate'];
            $expiryDate = $input['expiryDate'];

            $stmt = $pdo->prepare("INSERT INTO certificates (id, studentId, courseIds, candidateName, issueDate, expiryDate) VALUES (?, ?, ?, ?, ?, ?)");
            if ($stmt->execute([$id, $studentId, $courseIds, $candidateName, $issueDate, $expiryDate])) {
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false]);
            }
            break;

        case 'updateEnrollment':
            $id = $input['id'];
            $grade = $input['grade'] ?? null;
            $marks = $input['marks'] ?? null;
            $published = $input['published'] ?? 0;
            $status = $input['status'] ?? 'Active';

            $stmt = $pdo->prepare("UPDATE enrollments SET grade=?, marks=?, published=?, status=? WHERE id=?");
            if ($stmt->execute([$grade, $marks, $published, $status, $id])) {
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false]);
            }
            break;

        case 'addUser':
            $id = $input['id'];
            $name = $input['name'];
            $email = $input['email'];
            $password = $input['password']; // In real app, hash this!
            $role = $input['role'];
            $regNo = $input['regNo'] ?? null;
            $dob = $input['dob'] ?? null;
            $title = $input['title'] ?? null;

            // Check if exists
            $check = $pdo->prepare("SELECT id FROM users WHERE email=?");
            $check->execute([$email]);
            if ($check->fetch()) {
                echo json_encode(['success' => false, 'message' => 'Email exists']);
                exit;
            }

            $stmt = $pdo->prepare("INSERT INTO users (id, name, email, password, role, regNo, dob, title) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            if ($stmt->execute([$id, $name, $email, $password, $role, $regNo, $dob, $title])) {
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false, 'error' => $stmt->errorInfo()]);
            }
            break;

        case 'addCourse':
            $id = $input['id'];
            $code = $input['code'];
            $name = $input['name'];
            $masterId = $input['masterId'];
            $credits = $input['credits'];
            $description = $input['description'] ?? '';

            $stmt = $pdo->prepare("INSERT INTO courses (id, code, name, masterId, credits, description) VALUES (?, ?, ?, ?, ?, ?)");
            if ($stmt->execute([$id, $code, $name, $masterId, $credits, $description])) {
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false, 'error' => $stmt->errorInfo()]);
            }
            break;

        case 'deleteItem':
            $type = $input['type'];
            $id = $input['id'];
            $table = '';

            switch ($type) {
                case 'vg_users':
                    $table = 'users';
                    break;
                case 'vg_courses':
                    $table = 'courses';
                    break;
                case 'vg_enrollments':
                    $table = 'enrollments';
                    break;
                case 'vg_certificates':
                    $table = 'certificates';
                    break;
                case 'vg_posts':
                    $table = 'posts';
                    break;
                case 'vg_feedback':
                    $table = 'feedback';
                    break;
            }

            if ($table) {
                $stmt = $pdo->prepare("DELETE FROM $table WHERE id=?");
                if ($stmt->execute([$id])) {
                    echo json_encode(['success' => true]);
                } else {
                    echo json_encode(['success' => false]);
                }
            } else {
                echo json_encode(['success' => false, 'message' => 'Invalid table']);
            }
            break;
    }
}
?>