<?php
require_once 'db.php';

$id = $_GET['id'] ?? '';

if (!$id) {
    echo json_encode(['error' => 'No ID provided']);
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM certificates WHERE id = ?");
$stmt->execute([$id]);
$cert = $stmt->fetch();

if ($cert) {
    // Decode courseIds
    $courseIds = json_decode($cert['courseIds']);

    // Fetch course details
    $courses_details = [];
    if (is_array($courseIds) && count($courseIds) > 0) {
        $placeholders = str_repeat('?,', count($courseIds) - 1) . '?';
        $sql = "SELECT id, code, name FROM courses WHERE id IN ($placeholders)";
        $stmtCourses = $pdo->prepare($sql);
        $stmtCourses->execute($courseIds);
        $courses_details = $stmtCourses->fetchAll();
    }

    $cert['courses_details'] = $courses_details;

    echo json_encode($cert);
} else {
    echo json_encode(['error' => 'Certificate not found']);
}
?>