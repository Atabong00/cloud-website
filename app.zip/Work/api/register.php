<?php
require_once 'db.php';

// Get JSON POST data
$data = json_decode(file_get_contents('php://input'), true);

if (!$data) {
    echo json_encode(['success' => false, 'message' => 'No data received']);
    exit;
}

$name = $data['name'] ?? '';
$email = $data['email'] ?? '';
$password = $data['password'] ?? '';
$role = $data['role'] ?? 'student';
$dob = $data['dob'] ?? null;

if (!$name || !$email || !$password) {
    echo json_encode(['success' => false, 'message' => 'Missing fields']);
    exit;
}

// Check for duplicate email
$stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
$stmt->execute([$email]);
if ($stmt->fetch()) {
    echo json_encode(['success' => false, 'message' => 'Email already registered']);
    exit;
}

// Generate ID and RegNo
$id = 'u' . time() . rand(100, 999);
$regNo = ($role === 'student') ? 'REG' . date('Y') . rand(1000, 9999) : null;

$sql = "INSERT INTO users (id, name, email, password, role, dob, regNo) VALUES (?, ?, ?, ?, ?, ?, ?)";
$stmt = $pdo->prepare($sql);

if ($stmt->execute([$id, $name, $email, $password, $role, $dob, $regNo])) {
    echo json_encode([
        'success' => true,
        'user' => [
            'id' => $id,
            'name' => $name,
            'email' => $email,
            'role' => $role,
            'regNo' => $regNo
        ]
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'Database error during registration']);
}
?>